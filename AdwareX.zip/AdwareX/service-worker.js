self.addEventListener('push', event => {
  try {
    const data = event.data?.json() || {};

  const title = data.title || 'Bildirim';
  const options = {
    body: data.message || 'Mesaj yok.',
    icon: 'https://cdn-icons-png.flaticon.com/512/1827/1827392.png',
    requireInteraction: true,
    renotify: true
  };

  event.waitUntil(self.registration.showNotification(title, options));
  } catch (error) {
    console.error('Error showing notification:', error);
  }
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil(
    clients.openWindow('https://' + self.location.hostname)
  );
});
