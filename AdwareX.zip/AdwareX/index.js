const express = require('express');
const bodyParser = require('body-parser');
const webPush = require('web-push');
const path = require('path');

const app = express();
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname)));

const publicVapidKey = 'BMa-PBZEoEOWUiBErFTT-YHJ5-3ihbXkWFSQ89ikhd8a9c0o75g3wqovOItUQuioJ9--d_m1CcXaaII1J3BRnK8';
const privateVapidKey = 'cs4q6D-jvMATTm-0YZh9hdL9rgV5ELyUidgyUTaF0G0';

webPush.setVapidDetails('mailto:example@example.com', publicVapidKey, privateVapidKey);

let savedSubscription = null;

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/service-worker.js', (req, res) => {
  res.set('Content-Type', 'application/javascript');
  res.sendFile(path.join(__dirname, 'service-worker.js'));
});

app.post('/subscribe', (req, res) => {
  savedSubscription = req.body;
  console.log('Kayıt alındı!');
  res.status(201).json({ message: 'Abone kaydedildi' });
});

app.post('/notify', async (req, res) => {
  if (!savedSubscription) {
    return res.status(400).json({ error: 'Hiçbir abone yok.' });
  }

  const payload = JSON.stringify({
    title: 'Harika!',
    message: 'Bildirim başarıyla geldi!'
  });

  try {
    await webPush.sendNotification(savedSubscription, payload);
    res.status(200).json({ success: true });
  } catch (err) {
    console.error('Gönderim hatası:', err);
    res.sendStatus(500);
  }
});

// Automatic notification function
async function sendAutomaticNotification() {
  if (!savedSubscription) {
    console.log('No subscribers available');
    return;
  }

  const payload = JSON.stringify({
    title: 'Otomatik Bildirim',
    message: 'Bu otomatik bir bildirimdir!'
  });

  try {
    await webPush.sendNotification(savedSubscription, payload);
    console.log('Automatic notification sent successfully');
  } catch (err) {
    console.error('Automatic notification error:', err);
  }
}

// Set up 5-minute interval for notifications
setInterval(sendAutomaticNotification, 5 * 60 * 1000);

const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => console.log(`Sunucu çalışıyor: http://0.0.0.0:${PORT}`));
